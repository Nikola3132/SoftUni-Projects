﻿namespace FestivalManager.Core.Controllers.Contracts
{
	public interface IFestivalController
	{
		string LetsRock();

		string RegisterSet(string[] args);

		string SignUpPerformer(string[] args);

		string RegisterSong(string[] args);

		string AddSongToSet(string[] args);

		string AddPerformerToSet(string[] args);

		string RepairInstruments(string[] args);
        string ProduceReport();

    }
}