﻿namespace Cinema.Data
{
   public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-JU304LN\SQLEXPRESS;Database=Cinema;Integrated Security=true";
    }
}
